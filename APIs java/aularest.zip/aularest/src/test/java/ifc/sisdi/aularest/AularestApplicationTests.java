package ifc.sisdi.aularest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AularestApplicationTests {

	@Test
	void contextLoads() {
	}

}
